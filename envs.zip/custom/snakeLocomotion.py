import os
import gym
from gym import spaces, logger
from gym.utils import seeding
import gym.envs.custom.simulation as sim
import gym.envs.custom.render as ren
import numpy as np

# Load
dataPath = os.path.dirname(__file__) + "\\data\\"
sim.loadEnvironment(dataPath + "plane.obj", thickness = 0.001, penetrationCoef = 1., elasticityCoef = 0., frictionResistanceCoef = 50, frictionCoef = 10., scale = 100., basePosition = np.array([0., 0., 0.]), baseOrientation = np.array([0., 0., 0.]))
sim.loadSnake(dataPath + "snake.veg", timestep = 0.01, dampingMassCoef = 0, dampingStiffnessCoef = 0.01, gravity = 10., muscleStiffnessCoef = 10000., basePosition = np.array([0., 0.1, 0.]), baseOrientation = np.array([0., 0., 0.]))

# Snake Locomotion
class SnakeLocomotion(gym.Env):
    metadata = { 'render.modes': ['human'] }

    def __init__(self):
        # Action Space
        self.minContractRate = 0.5
        self.maxContractRate = 1.0
        self.action_space = spaces.Box(self.minContractRate, self.maxContractRate, shape=(sim.getNumMuscle(), ), dtype='float64')
        
        # Observation Space
        self.goalDirection = None
        self.upDirection = None
        self.cubePosition = None
        self.cubeVelocity = None
        self.muscleLength = None
        self.state = None
        self.observation_space = spaces.Box(-np.inf, np.inf, shape=(6 + 6 * sim.getNumCube() + sim.getNumMuscle(), ), dtype='float64')

        # Map
        self.mapBoundary = np.array([[-100, -100, -100], [100, 100, 100]], dtype='float64')
        self.goalBoundary = np.array([[-10, 0, -10], [10, 0, 10]], dtype='float64')
        self.goal = np.array([0, 0, 0], dtype='float64')
        self.goalDistance = 0.1
        self.distance = None

        # Simulation
        self.numStep = 10
        
        # Render
        self.viewer = True
        
        # Seed
        self.seed()

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def step(self, action):
        action = np.clip(action, self.minContractRate, self.maxContractRate).astype(np.float64)
        assert self.action_space.contains(action), "%r (%s) invalid " % (action, type(action))

        # Simulation
        for i in range(self.numStep):
            sim.contractMuscle(action)
            sim.simulate()
        vertex = sim.getVertexPosition()
        localFrame = sim.getInverseLocalFrame()

        # Render
        if self.viewer:
            self.render()

        # State
        self.goalDirection = localFrame @ normal(self.goal - vertex[7])
        self.upDirection = localFrame @ normal(np.array([0, 1, 0], dtype='float64'))
        self.cubePosition = sim.getCubePosition()
        for i in range(sim.getNumCube()):
            self.cubePosition[i] = localFrame @ (self.cubePosition[i] - vertex[7])
        self.cubePosition = self.cubePosition.reshape(3 * sim.getNumCube())
        self.cubeVelocity = (localFrame @ sim.getCubeVelocity().T).T.reshape(3 * sim.getNumCube())
        self.muscleLength = sim.getMuscleLength()
        self.state = np.concatenate([self.goalDirection, self.upDirection, self.cubePosition, self.cubeVelocity, self.muscleLength])

        # Reward
        currentDistance = length(self.goal - vertex[7])
        reward = 0
        reward1 = np.sin(self.goalDirection[0] * np.pi / 2)
        reward2 = np.sin(self.upDirection[1] * np.pi / 2)
        reward3 = np.exp(self.distance - currentDistance)
        if reward1 > 0 and reward2 > 0 and reward3 > 1:
            reward = reward1 + reward2 + reward3
        else:
            if reward1 < 0:
                reward = reward + reward1
            if reward2 < 0:
                reward = reward + reward2
            if reward3 < 1:
                reward = reward - (1 / reward3)
        self.distance = currentDistance

        # Done
        done = False
        if vertex[7][0] < self.mapBoundary[0][0] or vertex[7][0] > self.mapBoundary[1][0] or vertex[7][1] < self.mapBoundary[0][1] or vertex[7][1] > self.mapBoundary[1][1] or vertex[7][2] < self.mapBoundary[0][2] or vertex[7][2] > self.mapBoundary[1][2]:
            done = True
        if self.distance < self.goalDistance:
            done = True

        return np.array(self.state), reward, done, {}

    def reset(self):
        # Simulation
        sim.resetSimulation()
        vertex = sim.getVertexPosition()
        localFrame = sim.getInverseLocalFrame()

        # Map
        self.goal[0] = self.np_random.uniform(low=self.goalBoundary[0][0], high=self.goalBoundary[1][0], size=(1,))
        self.goal[1] = self.np_random.uniform(low=self.goalBoundary[0][1], high=self.goalBoundary[1][1], size=(1,))
        self.goal[2] = self.np_random.uniform(low=self.goalBoundary[0][2], high=self.goalBoundary[1][2], size=(1,))
        sim.setGoal(self.goal[0], self.goal[1], self.goal[2])
        self.distance = length(self.goal - vertex[7])

        # State
        self.goalDirection = localFrame @ normal(self.goal - vertex[7])
        self.upDirection = localFrame @ normal(np.array([0, 1, 0], dtype='float64'))
        self.cubePosition = sim.getCubePosition()
        for i in range(sim.getNumCube()):
            self.cubePosition[i] = localFrame @ (self.cubePosition[i] - vertex[7])
        self.cubePosition = self.cubePosition.reshape(3 * sim.getNumCube())
        self.cubeVelocity = (localFrame @ sim.getCubeVelocity().T).T.reshape(3 * sim.getNumCube())
        self.muscleLength = sim.getMuscleLength()
        self.state = np.concatenate([self.goalDirection, self.upDirection, self.cubePosition, self.cubeVelocity, self.muscleLength])

        return np.array(self.state)

    def render(self, mode='human'):
        if not ren.isOpenWindow():
            ren.createWindow()
            
        ren.render()

    def close(self):
        ren.destroyWindow()

def length(vec):
        return np.sqrt(np.dot(vec, vec))
    
def normal(vec):
        return vec / length(vec)
