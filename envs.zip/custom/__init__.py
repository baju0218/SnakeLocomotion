from gym.envs.custom.snakeLocomotion import SnakeLocomotion

